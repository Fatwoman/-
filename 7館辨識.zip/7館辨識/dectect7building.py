import cv2

model = cv2.CascadeClassifier('haar_model/cascade.xml')
img = cv2.imread('test6.jpg')  # 改成你要測試的圖片
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

boxes = model.detectMultiScale(gray, 1.1, 5)

for (x, y, w, h) in boxes:
    cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)

if len(boxes) > 0:
    print("✅ 是7館")
else:
    print("❌ 不是7館")

cv2.imshow("Result", img)
cv2.waitKey(0)
cv2.destroyAllWindows()